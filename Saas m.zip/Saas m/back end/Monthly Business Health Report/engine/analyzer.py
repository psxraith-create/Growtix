# analyzer.py
import pandas as pd

def analyze_data(sales_df, expense_df):
    """
    Returns a summary dictionary with KPIs
    """
    total_sales = sales_df['sale_amount'].sum()
    total_cost = sales_df['cost'].sum()
    net_profit = total_sales - total_cost
    profit_margin = (net_profit / total_sales) * 100 if total_sales != 0 else 0

    # Expense summary
    expense_summary = expense_df.groupby('category')['amount'].sum().reset_index()

    # Product-wise profit
    sales_df['profit'] = sales_df['sale_amount'] - sales_df['cost']
    product_profit = sales_df.groupby('item')['profit'].sum().reset_index().sort_values(by='profit', ascending=False)

    summary = {
        'total_sales': total_sales,
        'total_cost': total_cost,
        'net_profit': net_profit,
        'profit_margin': profit_margin,
        'expense_summary': expense_summary,
        'product_profit': product_profit
    }

    return summary

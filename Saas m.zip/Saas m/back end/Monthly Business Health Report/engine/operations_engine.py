# business_health_reporter/core/operations_engine.py
import pandas as pd

def analyze_operations(df):
    """
    Handle text-based fields: Operational Issues, Risks Identified, Opportunities Identified, Automation / AI Systems Used.
    Returns a dictionary with collected text data.
    """
    insights = {}

    try:
        text_fields = [
            'Operational Issues',
            'Risks Identified',
            'Opportunities Identified',
            'Automation / AI Systems Used'
        ]

        for field in text_fields:
            if field in df.columns:
                # Collect all non-null values
                values = df[field].dropna().tolist()
                insights[field.lower().replace(' ', '_').replace('/', '_')] = values
            else:
                insights[field.lower().replace(' ', '_').replace('/', '_')] = []

    except Exception as e:
        insights['error'] = str(e)

    return insights
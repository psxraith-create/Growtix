# core/supplier_analysis.py
import pandas as pd

def analyze_suppliers(df):
    """
    Analyze suppliers based on margins and performance.
    """
    supplier_analysis = df.groupby('Supplier').agg({
        'Quantity': 'sum',
        'Selling_Price': 'mean',
        'Cost_Price': 'mean',
        'Product': 'nunique'  # Number of products
    }).reset_index()

    supplier_analysis['Total_Revenue'] = supplier_analysis['Quantity'] * supplier_analysis['Selling_Price']
    supplier_analysis['Total_Cost'] = supplier_analysis['Quantity'] * supplier_analysis['Cost_Price']
    supplier_analysis['Profit'] = supplier_analysis['Total_Revenue'] - supplier_analysis['Total_Cost']
    supplier_analysis['Margin'] = (supplier_analysis['Profit'] / supplier_analysis['Total_Revenue']) * 100

    # Sort by margin
    supplier_analysis = supplier_analysis.sort_values('Margin', ascending=False)

    # Best and worst suppliers
    best_suppliers = supplier_analysis.head(2)
    worst_suppliers = supplier_analysis.tail(2)

    return {
        'supplier_summary': supplier_analysis,
        'best_suppliers': best_suppliers,
        'worst_suppliers': worst_suppliers
    }
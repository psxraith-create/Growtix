# data_loader.py
import pandas as pd

def load_data(file_path):
    """
    Load sales and expense data from Excel file.
    Returns cleaned DataFrames.
    """
    # Read the sheet
    df = pd.read_excel(file_path, sheet_name="monthly_business_data")

    # Standardize column names
    df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_")

    # Create sales_df by selecting and renaming relevant columns
    sales_df = df[['date', 'product_name', 'units_sold', 'revenue', 'cost']].copy()
    sales_df = sales_df.rename(columns={'product_name': 'item', 'revenue': 'sale_amount'})

    # Create expense_df from marketing spend and other costs
    # Group by date and sum ad_spend as marketing expense
    expense_df = df.groupby('date')['ad_spend'].sum().reset_index()
    expense_df['category'] = 'Marketing'
    expense_df = expense_df.rename(columns={'ad_spend': 'amount'})

    # Ensure numeric columns
    numeric_cols_sales = ['units_sold', 'sale_amount', 'cost']
    for col in numeric_cols_sales:
        if col in sales_df.columns:
            sales_df[col] = pd.to_numeric(sales_df[col], errors='coerce').fillna(0)
    expense_df['amount'] = pd.to_numeric(expense_df['amount'], errors='coerce').fillna(0)

    return sales_df, expense_df

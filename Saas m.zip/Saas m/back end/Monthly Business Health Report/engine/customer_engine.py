# business_health_reporter/core/customer_engine.py
import pandas as pd

def analyze_customers(df):
    """
    Analyze customer metrics: Total Customers, New Customers, Lost Customers, Churn Rate, CLV.
    Returns a dictionary with metrics.
    """
    insights = {}

    try:
        # Total Customers
        if 'Total Customers' in df.columns:
            insights['total_customers'] = df['Total Customers'].sum()  # or mean? probably sum if monthly totals
        else:
            insights['total_customers'] = None

        # New Customers
        if 'New Customers' in df.columns:
            insights['total_new_customers'] = df['New Customers'].sum()
        else:
            insights['total_new_customers'] = None

        # Lost Customers
        if 'Lost Customers' in df.columns:
            insights['total_lost_customers'] = df['Lost Customers'].sum()
        else:
            insights['total_lost_customers'] = None

        # Churn Rate (%)
        if 'Lost Customers' in df.columns and 'Total Customers' in df.columns:
            total_lost = df['Lost Customers'].sum()
            avg_total = df['Total Customers'].mean()  # use average total customers
            insights['churn_rate'] = (total_lost / avg_total) * 100 if avg_total != 0 else 0
        else:
            insights['churn_rate'] = None

        # CLV (Customer Lifetime Value)
        if 'Avg Order Value' in df.columns and 'Purchase Frequency' in df.columns and 'Customer Lifespan' in df.columns:
            avg_order_value = df['Avg Order Value'].mean()
            purchase_freq = df['Purchase Frequency'].mean()
            lifespan = df['Customer Lifespan'].mean()
            insights['clv'] = avg_order_value * purchase_freq * lifespan
        else:
            insights['clv'] = None

    except Exception as e:
        insights['error'] = str(e)

    return insights

# core/investment_engine.py
import pandas as pd

def calculate_roi(df):
    """
    Calculate ROI per product and provide investment recommendations.
    """
    # Calculate total investment (cost) and return (revenue) per product
    product_roi = df.groupby('Product').agg({
        'Quantity': 'sum',
        'Selling_Price': 'mean',
        'Cost_Price': 'mean'
    }).reset_index()

    product_roi['Total_Revenue'] = product_roi['Quantity'] * product_roi['Selling_Price']
    product_roi['Total_Cost'] = product_roi['Quantity'] * product_roi['Cost_Price']
    product_roi['Profit'] = product_roi['Total_Revenue'] - product_roi['Total_Cost']
    product_roi['ROI'] = (product_roi['Profit'] / product_roi['Total_Cost']) * 100

    # Recommendations
    recommendations = {}
    for _, row in product_roi.iterrows():
        product = row['Product']
        roi = row['ROI']
        profit = row['Profit']

        if roi > 50 and profit > 1000:
            rec = "Highly recommended for increased investment - excellent ROI and profits."
        elif roi > 20:
            rec = "Good investment opportunity - solid ROI."
        elif roi > 0:
            rec = "Moderate investment - break-even or low profits."
        else:
            rec = "Avoid investment - negative ROI and losses."

        recommendations[product] = {
            'ROI': roi,
            'Recommendation': rec
        }

    return recommendations
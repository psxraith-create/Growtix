# report.py
import pandas as pd
import os

def generate_report(summary, output_file):
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    
    with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
        # Summary sheet
        summary_df = pd.DataFrame({
            'Metric': ['Total Sales', 'Total Cost', 'Net Profit', 'Profit Margin (%)'],
            'Value': [summary['total_sales'], summary['total_cost'], summary['net_profit'], summary['profit_margin']]
        })
        summary_df.to_excel(writer, sheet_name='Summary', index=False)

        # Expense sheet
        summary['expense_summary'].to_excel(writer, sheet_name='Expenses', index=False)

        # Product Profit sheet
        summary['product_profit'].to_excel(writer, sheet_name='Product Profit', index=False)

        # Add charts to summary sheet
        workbook = writer.book
        worksheet = writer.sheets['Summary']
        worksheet.insert_image('F2', 'output/charts/sales_trend.png')
        worksheet.insert_image('F20', 'output/charts/expense_breakdown.png')
